import { ThemeProvider, CssBaseline } from "@mui/material";
import { Routes, Route } from "react-router-dom";
import { lightTheme, darkTheme } from "./components/theme";
import CardLayout from "./components/cardsMovies/cardsLayout";
import React, { useState } from "react";
import Navbar from "./components/navbar";
import NewUserModal from "./components/createUser";
import EditUser from "./components/editUser";

function App() {
  const [useLightTheme, setUseLightTheme] = useState(true);
  const selectedTheme = useLightTheme ? lightTheme : darkTheme;
  const [layout, setLayout] = useState("grid");

  const toggleTheme = () => {
    setUseLightTheme((prevTheme) => !prevTheme);
  };

  return (
    <ThemeProvider theme={selectedTheme}>
      <CssBaseline />
      <div>
        <Navbar toggleTheme={toggleTheme} useLightTheme={useLightTheme} />
        <main>
          <Routes>
            <Route
              path="/"
              element={<CardLayout layout={layout} setLayout={setLayout} />}
            />{" "}
          </Routes>
        </main>
        <footer>{/* Add your footer content here */}</footer>
      </div>
    </ThemeProvider>
  );
}

export default App;
