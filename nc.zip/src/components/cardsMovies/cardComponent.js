import React from 'react';
import { Card, CardContent, CardMedia, Typography, IconButton, Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import '../../../src/styles.css'


const CardComponent = ({ directorName, releaseDate, image, title, description, handleEditClick, handleDeleteClick }) => {
  return (
    <div className="scrollable">
      <Card variant="outlined" sx={{ position: 'relative', overflow: 'visible' }}>
        <Box sx={{ position: 'absolute', top: 0, right: 0 }}>
          <IconButton onClick={handleEditClick} color="primary" size='small'>
            <EditIcon fontSize='small' />
          </IconButton>
          <IconButton onClick={handleDeleteClick} color="error" size='small'>
            <DeleteIcon fontSize='small' />
          </IconButton>
        </Box>
        <CardMedia
          component="img"
          height="140"
          image={image} // Add the URL of the image here
          alt={title}
        />
        <CardContent>
          <Typography gutterBottom variant="h6" component="div">
            {title}
          </Typography>
          <Typography gutterBottom variant="body1" component="div">
            {directorName}
          </Typography>
          <Typography gutterBottom variant="body1" component="div">
            {releaseDate}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {description}
          </Typography>
        </CardContent>
      </Card>
    </div>

  );
};

export default CardComponent;




