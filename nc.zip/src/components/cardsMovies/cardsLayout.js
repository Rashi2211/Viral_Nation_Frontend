import React, { useEffect, useState } from 'react';
import {
  Container, 
  Button, 
  Box, 
  Pagination, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import CardsGrid from './cardGrid';
import CardsTable from './cardTable';
import SearchBar from './search';
import EditUser from '../editUser';
import NewMovieForm from '../createUser';
import { useLazyQuery} from '@apollo/client';
import { GET_ALL_MOVIES } from '../../queries/GetAllMovies';
import { useMutation } from '@apollo/client';
import { CREATE_MOVIE } from '../../queries/CreateMovie';
import { EDIT_MOVIES } from '../../queries/Edit';
import { DELETE_MOVIE } from '../../queries/DeleteMovie';





const CardLayout = () => {
  const [layout, setLayout] = useState('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(12);
  const [createFormOpen, setCreateFormOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [editCardOpen, setEditCardOpen] = useState(false);
  const [totalData, setTotalData] = useState([]);
  const [movies, setMovies] = useState([]);
  const [totalRows, setTotalRows] = useState(0); // Total number of rows
  const [searchQueryDebounced, setSearchQueryDebounced] = useState('');
  const [getAllMovies, { loading: getAllMoviesLoading, data: getAllMoviesData }] = useLazyQuery(GET_ALL_MOVIES);
  const [cardData, setCardData] = useState(getAllMoviesData);
  const [newCardData, setNewCardData] = useState({
    image: '',
    title: '',
    directorName: '',
    releaseDate: '',
    description: '',
  });
  const itemsPerPage = 9;
  const [createMovie] = useMutation(CREATE_MOVIE);
  const [editMovie] = useMutation(EDIT_MOVIES);
  const [deleteMovie] = useMutation(DELETE_MOVIE);

  useEffect(() => { if (!getAllMoviesLoading && getAllMoviesData?.movies?.movies) { setTotalData([...totalData, ...getAllMoviesData.movies.movies]); setMovies(getAllMoviesData.movies.movies); setTotalRows(getAllMoviesData.movies.total_rows) } }, [totalData,getAllMoviesData, getAllMoviesLoading])
  useEffect(() => {
    getAllMovies({
      variables: {
        page: currentPage - 1,
        rows: rowsPerPage,
        sort: {
          order: null,
          column: null
        },
        search: searchQueryDebounced
      }
    })
  }, [searchQueryDebounced, currentPage, getAllMovies, rowsPerPage]);

  const handleCreateMovie = async (newMovieData) => {
    console.log('New Movie Data:', newMovieData);
    try {
      const { data } = await createMovie({
        variables: {
          // Check the expected variable name in your mutation
          image: newMovieData.image,
          name: newMovieData.title,
          description: newMovieData.description,
          directorName: newMovieData.directorName,
          releaseDate: newMovieData.releaseDate,

        },
        refetchQueries: [{ query: GET_ALL_MOVIES }],
      });
      setNewCardData({
        image: newMovieData.image,
        title: newMovieData.name,
        description: newMovieData.description,
        directorName: newMovieData.directorName,
        releaseDate: newMovieData.releaseDate,
      });
      window.location.reload();
    } catch (error) {
      console.error('Error creating movie:', error);
    }
  };

  const debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func(...args);
      }, delay);
    };
  };

  const handleDebounceSearch = debounce((query) => {
    setTotalData([]);
    setSearchQueryDebounced(query);
  }, 1000);

  const handleSearch = (event) => {
    const query = event.target.value;
    setSearchQuery(query);
    handleDebounceSearch(query);
  };


  const handlePaginationChange = (event, value) => {
    setCurrentPage(value); // Update the current page when pagination is changed
  };

  const handleCreateFormOpen = () => {
    setCreateFormOpen(true);
  };

  const handleCreateFormClose = () => {
    setCreateFormOpen(false);
    setNewCardData({ image: '', title: '', description: '', directorName: '', releaseDate: '' }); // Clear input fields when closing
  };

  const handleEditClick = (card) => {
    console.log('Editing Card:', card);
    setEditingCard(card);
    setEditCardOpen(true);
  };

  const handleUpdateCard = async (updatedCard) => {
    console.log('Updated Card: line number 187', updatedCard);
    try {
      const { data } = await editMovie({
        variables: {
          editMovieId: updatedCard.id, // Use editMovieId instead of id
          name: updatedCard.title,
          description: updatedCard.content,
          directorName: updatedCard.directorName,
          releaseDate: updatedCard.releaseDate,
          image: updatedCard.image,
        },
      });
      console.log('Edited Movie:', data.editMovie);
      const updatedCardData = cardData.map((card) =>
        card.id === updatedCard.id ? data.editMovie : card
      );
      setCardData(updatedCardData);
      setEditCardOpen(false); // Close the edit dialog
    } catch (error) {
      console.log('Updated Card: line number 187error');
      console.error('Error editing movie:', error);
    }
  };

  const handleEditFormClose = () => {
    setEditCardOpen(false);
    setEditingCard(null);
  };
  const handleDeleteClick = (card) => {
    setEditingCard(card);
    setDeleteModalOpen(true);
  };
  const handleDeleteConfirm = async () => {
    if (editingCard) {
      await deleteMovie({
        variables: {
          deleteMovieId: editingCard.id
        },
        refetchQueries: [{ query: GET_ALL_MOVIES }],
      });
      window.location.reload();
    }
    setDeleteModalOpen(false);
  };

  const handleRowsPerPageChange = (event) => {
    const rowsPerPage = parseInt(event.target.value, 10);
    setCurrentPage(1); // Reset page number when changing rows per page
    setRowsPerPage(rowsPerPage); // Update rows per page state
  };


  return (
    <Container maxWidth="lg" >
      <Box
        minHeight="100vh"
        display="flex"
        flexDirection="column"
        justifyContent="space-between"
        position="relative"
        marginBottom="3rem" /* Add margin to the bottom of the card container */
      >
        <div>
          <SearchBar
            searchQuery={searchQuery}
            handleSearch={handleSearch}
            handleCreateFormOpen={handleCreateFormOpen}
            newCardData={newCardData}
            setNewCardData={setNewCardData}
            createFormOpen={createFormOpen}
            handleCreateFormClose={handleCreateFormClose}
            setLayout={setLayout}
          />
          <NewMovieForm
            open={createFormOpen}
            handleClose={handleCreateFormClose}
            handleCreateMovie={handleCreateMovie}
          />

          {layout === 'grid' && movies.length > 0 ? (
            <CardsGrid
              searchQuery={searchQuery}
              data={totalData}
              handleEditClick={handleEditClick}
              handleDeleteClick={handleDeleteClick}
              total_rows={totalRows}
              page={currentPage}
              setCurrentPage={setCurrentPage}
            />
          ) : layout === 'table' && movies.length > 0 ? (
            <CardsTable
              searchQuery={searchQuery}
              data={movies}
              handleEditClick={handleEditClick}
              handleDeleteClick={handleDeleteClick}
            />
          ) : null}
          <EditUser
            open={editCardOpen} // Pass the state variable to control the modal
            handleClose={handleEditFormClose}
            editingCard={editingCard}
            handleUpdateCard={handleUpdateCard}
          />
          <Dialog open={deleteModalOpen} onClose={() => setDeleteModalOpen(false)}>
            <DialogTitle>Delete Confirmation</DialogTitle>
            <DialogContent>
              Are you sure you want to delete this card?
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDeleteModalOpen(false)} color="primary">
                Cancel
              </Button>
              <Button onClick={handleDeleteConfirm} color="primary">
                Delete
              </Button>
            </DialogActions>
          </Dialog>
          <footer>



            <Box display="flex"
              justifyContent="space-between"
              alignItems="center"
              padding="0.1rem"
              backgroundColor="grey.100"
              position="fixed"
              bottom="0"
              zIndex="100"
              sx={{ flexGrow: 1 }}>
              {
                layout === 'table' &&

                <FormControl>
                  <InputLabel>Rows Per Page</InputLabel>
                  <Select
                    value={rowsPerPage}
                    onChange={handleRowsPerPageChange}
                    style={{ minWidth: '100px' }} // Adjust the width as needed
                  >
                    <MenuItem value={6}>6</MenuItem>
                    <MenuItem value={9}>9</MenuItem>
                    <MenuItem value={12}>12</MenuItem>
                  </Select>
                </FormControl>
                &&
                <Pagination
                  count={Math.ceil(totalRows / itemsPerPage)}
                  page={currentPage}
                  onChange={handlePaginationChange}
                  color="primary"
                />
              }
            </Box>
          </footer>
        </div>
      </Box>
    </Container>
  );
};

export default CardLayout;
