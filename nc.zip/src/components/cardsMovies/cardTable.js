import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';


const CardsTable = ({ data, handleDeleteClick, handleEditClick }) => {

  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }}>
        <TableHead>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold', fontSize: '1rem' }}>ID</TableCell>
            <TableCell sx={{ fontWeight: 'bold', fontSize: '1rem' }}>Title</TableCell>
            <TableCell sx={{ fontWeight: 'bold', fontSize: '1rem' }}>Plot</TableCell>
            <TableCell sx={{ fontWeight: 'bold', fontSize: '1rem' }}>Director</TableCell>
            <TableCell sx={{ fontWeight: 'bold', fontSize: '1rem' }}>Released</TableCell>

          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((card) => (
            <TableRow key={card.id}>
              <TableCell>{card.id}</TableCell>
              <TableCell>{card.name}</TableCell>
              <TableCell>{card.description}</TableCell>
              <TableCell>{card.directorName}</TableCell>
              <TableCell>{card.releaseDate}</TableCell>
              <IconButton onClick={() => handleEditClick(card)} color="primary">
                <EditIcon />
              </IconButton>
              <IconButton onClick={() => handleDeleteClick(card)} color="error">
                <DeleteIcon />
              </IconButton>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default CardsTable;
