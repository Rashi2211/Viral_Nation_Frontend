import React from 'react';
import { Grid } from '@mui/material';
import CardComponent from './cardComponent';
import InfiniteScroll from "react-infinite-scroll-component";

const CardsGrid = ({ data, handleDeleteClick, handleEditClick, total_rows, page, setCurrentPage }) => {

  return (
    <Grid container spacing={4}>
      <InfiniteScroll
        dataLength={data.length}
        next={() => { setCurrentPage(page + 1) }}
        hasMore={total_rows < data.length ? false : true}
        loader={<h4>Loading...</h4>}
      >
        {data.map((card) => (
          <Grid item xs={12} sm={6} md={4} key={card.id}>
            <CardComponent
              image={card.image}
              id={card.id}
              directorName={card.directorName}
              releaseDate={card.releaseDate}
              title={card.name}
              description={card.description}
              handleEditClick={() => handleEditClick(card)}
              handleDeleteClick={() => handleDeleteClick(card)}
            />
          </Grid>
        ))}
      </InfiniteScroll>
    </Grid>
  );
};

export default CardsGrid;
