// theme.js
import { createTheme } from "@mui/material/styles";

const lightTheme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#007bff", // Replace with your primary color
    },
    secondary: {
      main: "#6c757d", // Replace with your secondary color
    },
    background: {
      default: "#f8f9fa", // Replace with your background color
    },
  },
  typography: {
    fontFamily: "Arial, sans-serif", // Replace with your desired font-family
  },
});

const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#007bff", // Replace with your primary color
    },
    secondary: {
      main: "#6c757d", // Replace with your secondary color
    },
    background: {
      default: "#121212", // Replace with your dark background color
    },
  },
  typography: {
    fontFamily: "Arial, sans-serif", // Replace with your desired font-family
  },
});

export { lightTheme, darkTheme };
